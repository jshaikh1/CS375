#include <iostream>
#include <cstring>
#include <fstream>
#include <sstream>
#include <map>
#include <math.h>
#include <vector>
#include <numeric>
#include <assert.h>
using namespace std;

map<string, int> marketCards;
vector<int> subsets;
vector<string> subsetCardNames;


map<int, string> indexedCardNames;
map<int, int> indexedPriceListCards;
map<int, int> indexedMarketPriceCards;
vector<int> cardIndexes;


void readMarketPriceCards(string marketPriceFile)
{
    string marketCardName;
    int numMarketPriceCards;  
    int marketPrice;
    int count = 0;

    ifstream read(marketPriceFile);
    read >> numMarketPriceCards;

    //insert market file cardnames and prices into marketCards map
    while(read >> marketCardName >> marketPrice && count < numMarketPriceCards)
    {
        marketCards.insert({marketCardName, marketPrice});
        count++;
    }
}


void calculateMaxProfit(string priceListFile, string marketPriceFile)
{
    //start time in seconds
    const clock_t begin_time = clock();

    //parse through priceListFile
    ifstream in(priceListFile);
    
    string line;
    int index = 0;
    int numCards = 0;
    int budget = 0;


    while (in.good()) 
    {
        //read each line from file
        getline(in, line);
        
        //separate words from each line
        istringstream iss(line);
        string word, cardName, cardPrice;
         
         // read number of cards
        iss >> word;
        numCards = stoi(word);
        // read list price
        iss >> word;
        budget = stoi(word);

        // read lines upto numCards
        for(int i = 0; i < numCards; i++)
        {
            getline(in, line);
            istringstream card(line);
            
            // parse line for cardname and price
            card >> cardName;
            card >> cardPrice;
            
            int iCardPrice = stoi(cardPrice);
            bool cardFound = false;

            //store list price, card name at same indexes
            for(auto itr = marketCards.begin(); itr != marketCards.end(); itr++)
            {
                //store matched cards into indexed market price cards
                if(cardName == itr->first)
                {
                    cardFound = true;
                    indexedMarketPriceCards.insert({index, itr->second});
                    indexedPriceListCards.insert({index, iCardPrice});
                    indexedCardNames.insert({index, cardName});
                    index++;
                }
            }
            if(!cardFound)
            {
                cerr << "No match for [" << cardName << "] found in the market price file." << endl;
                exit(1);
            }
        }

        //reset index for next problem
        index = 0;
        
        //now generate subsets using binary 
        int n = indexedPriceListCards.size();
        int subsetCount = pow(2, n);
        int SumOfSubsetPrice = 0;
        int SumOfMarketPrice = 0;
        string stringOfSubsets = "";
        int nCardsInSubset = 0;
        int maxSubsetProfit = 0;
        int finalCardsInSubset = 0;
        vector<int> finalSubset;
        vector<string> finalCardNames;
        bool overBudget = false;
        
        for (int i = 0; i < subsetCount; i++) 
        {
            stringOfSubsets = "";
            nCardsInSubset = 0;
            SumOfSubsetPrice = 0;
            SumOfMarketPrice = 0;
            subsets.clear();
            subsetCardNames.clear();

            
            for (int j = 0; j < n; j++) 
            {
                if ((i & (1 << j)) != 0)
                {
                    //concatenate the formed subsets to a string
                    stringOfSubsets = stringOfSubsets + to_string(indexedPriceListCards.at(j)) + ' ';
                    nCardsInSubset++;

                    //sum the listPrice for this set
                    SumOfSubsetPrice += indexedPriceListCards.at(j);

                    //sum the marketPrice for this set
                    SumOfMarketPrice += indexedMarketPriceCards.at(j);

                    //store current subset into subsets vector
                    subsets.push_back(indexedPriceListCards.at(j));

                    //store the cards in current subset into a vector for output
                    subsetCardNames.push_back(indexedCardNames.at(j));
                }
            }

            //check if current profit is > maxSubsetProfit, and that the SumOfSubsetPrice is within budget
            if((SumOfMarketPrice - SumOfSubsetPrice) > maxSubsetProfit && SumOfSubsetPrice <= budget)
            {
                //calculate and update maxProfit
                maxSubsetProfit = SumOfMarketPrice - SumOfSubsetPrice;

                //update the number of cards in the subset
                finalCardsInSubset = nCardsInSubset;

                finalSubset.clear();
                for (unsigned int i=0; i<subsets.size(); i++) 
                    finalSubset.push_back(subsets[i]); 

                finalCardNames.clear();
                for (unsigned int i=0; i<subsetCardNames.size(); i++) 
                    finalCardNames.push_back(subsetCardNames[i]);
            }
        }

        //if everything is over budget, that means you can't buy any cards
        if(overBudget)
        {
            cout << "None of the cards are within your budget." << endl;
        }
        else
        {
            cout << "Size of input: " << numCards << endl;
            cout << "maxProfit for this subset: $" << maxSubsetProfit << endl;
            cout << "number of cards you can purchase: " << finalCardsInSubset << endl;
            cout << "Execution time in seconds: " << float( clock () - begin_time ) /  CLOCKS_PER_SEC << endl;

            //print the cardNames in the final subset using stored indexes
            for(unsigned int i=0; i < finalCardNames.size(); i++)
                cout << finalCardNames.at(i) << " " << endl;
            cout << endl;
        }
                
        //reset all variables for next problem
        indexedCardNames.clear();
        indexedMarketPriceCards.clear();
        indexedPriceListCards.clear();
    }    
}




//main method
int main(int argc, char *argv[])
{
    //check for proper number of arguments
    if(argc != 5)
    {
        cout << "Please enter the correct number of arguments." << endl;
    }
    //check for proper flags
    if((!strcmp(argv[1], "-m") == 0) || (!strcmp(argv[3], "-p") == 0))
    {
        cout << "Please enter the proper flags." << endl;
    }

    string marketPriceFile;
    string priceListFile;

    //store files into variables
    marketPriceFile = argv[2];
    priceListFile = argv[4];

    //read in cards from market price file
    readMarketPriceCards(marketPriceFile);
    //call function to calculate max profit
    calculateMaxProfit(priceListFile, marketPriceFile);
}

